<style>    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1, h2, h3 {
            color: #333;
        }
        p, ul, li {
            color: #555;
        }
        .home-button {
            display: block;
            margin: 20px auto 0;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s ease;
        }
        .home-button:hover {
            background-color: #0056b3;
        }
    </style></style>


<a href="./">
 
</a>

&nbsp;</br></br>




<link rel="canonical" href="https://bayasolsticeofficial.com/Terms.php">

<article id="post-611" class="post-611 page type-page status-publish hentry">
	

	
	<div class="entry-content">
		<div class="container">
      <div class="row">
        <div class="col-sm-8 col-sm-offset-2" style="padding: 0 35px;">

		<p>&nbsp;</p>
        <h1 class="entry-title">Terms Of Use</h1>
<p>&nbsp;</p>
<p style="text-align: left;">MAHA RERA Act have come into effect from 1st may 2017. The content of website may not be be fully compliant with RERA as of date. We are in process of revising further details required as per RERA if pending any.</p>
<p style="text-align: left;">We all possible measures to avoid any misrepresenration but makes no warranties as to the content and information accuracy. While reasonable efforts are being made to ensure the authenticity and completeness of the Information displayed here and the same is updated at regular intervals there is a possibility that the information displayed may not be current and incomplete.</p>
<p style="text-align: left;">Please make sure you verify all the details from the actual site office or from the RERA website before making any decision in relation to the purchase of the properties.</p>
<p style="text-align: left;">We accept no liability for the content of this website content, or for the consequences of any actions taken on the basis of this website or content. Property Prices, location map image, master plan image, opinion/suggestions provided in this mail are subject to change without notice and shall in no way make us responsible for any loss/damages caused to the users/members.</p>
    </div>
    </div>

         <a href="index.html" class="home-button">Return to Home Page</a>
  </div>  